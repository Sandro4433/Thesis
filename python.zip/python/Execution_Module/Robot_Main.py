
import rospy
import moveit_commander
from geometry_msgs.msg import Pose

from Execution_Module.pick_and_place import pick_and_place
from Execution_Module.robot import Robot

from pathlib import Path
import sys

PROJECT_DIR = Path(__file__).resolve().parents[1]  # .../python
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

rospy.init_node("franka_go_points")
moveit_commander.roscpp_initialize([])

robot = Robot("panda_arm", "panda_hand", moveit_commander)

robot.MoveJ_J("Camera_Home")



#pick_and_place(robot, "Container_1_Pos_1", "Kit_0_Pos_1")


robot.MoveJ_J("Camera_Home")

